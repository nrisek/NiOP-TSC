﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Program
    {
        static void Main(string[] args)
        {

        }
        public class Korisnik
        {
            protected int clanski_broj;
            protected string ime_prezime = "";
            protected string adresa = "";
            protected string broj_telefona="";
            public Korisnik(int cl_br, string ime_prez, string adr, string br_tele)
            {
                this.clanski_broj = cl_br;
                this.ime_prezime = ime_prez;
                this.adresa = adr;
                this.broj_telefona = br_tele;
            }
            public int dohvatiClanskiBroj()
            {
                return this.clanski_broj;
            }
            public string dohvatiImeIPrezime()
            {
                return this.ime_prezime;
            }
            public string dohvatiAdresu()
            {
                return this.adresa;
            }
            public string dohvatiBrojTelefona()
            {
                return this.broj_telefona;
            }
            public string Ispis()
            {
                string ispis="Clanski broj: "+this.clanski_broj+"\n"+
                    "Ime i Prezime: " + this.ime_prezime+"\n"+
                    "Adresa: " + this.adresa+"\n"+
                    "Broj telefona: " + this.broj_telefona+"\n";
                return ispis;
            }
        }
        public class Film
        {

        }
    }
}

