﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Program
    {
        static void Main(string[] args)
        {

        }
        public class Korisnik
        {
            protected int clanski_broj;
            protected string ime_prezime = "";
            protected string adresa = "";
            protected string broj_telefona="";
            public Korisnik(int cl_br, string ime_prez, string adr, string br_tele)
            {
                this.clanski_broj = cl_br;
                this.ime_prezime = ime_prez;
                this.adresa = adr;
                this.broj_telefona = br_tele;
            }
            public int dohvatiClanskiBroj()
            {
                return this.clanski_broj;
            }
            public string dohvatiImeIPrezime()
            {
                return this.ime_prezime;
            }
            public string dohvatiAdresu()
            {
                return this.adresa;
            }
            public string dohvatiBrojTelefona()
            {
                return this.broj_telefona;
            }
            public string Ispis()
            {
                string ispis="Clanski broj: "+this.clanski_broj+"\n"+
                    "Ime i Prezime: " + this.ime_prezime+"\n"+
                    "Adresa: " + this.adresa+"\n"+
                    "Broj telefona: " + this.broj_telefona+"\n";
                return ispis;
            }
        }
        public class Film
        {
            protected int evidencijski_broj = 0;
            protected bool trak_ili_DVD = true; //ako true onda je DVD
            protected string naziv_filma = "";
            protected string zanr = "";
            protected int godina_produkcije = 0;
            //public zaduzenje[]=newInt[10]?
            public Film(int evid_broj, bool traka_DVD, string naz_filma, string zanrr, int god_prod)
            {
                this.evidencijski_broj = evid_broj;
                this.trak_ili_DVD = traka_DVD;
                this.naziv_filma = naz_filma;
                this.zanr = zanrr;
                this.godina_produkcije = god_prod;
            }
            public int dohvatiEvidencijskiBroj()
            {
                return this.evidencijski_broj;
            }
            public string dohvatiNaziv()
            {
                return this.naziv_filma;
            }
            public string dohvatiZanr()
            {
                return this.zanr;
            }
            public int dohvatiGodinuProdukcije()
            {
                return this.godina_produkcije;
            }
            public string dohvatiJeLiDVD()
            {
                if (this.trak_ili_DVD)
                    return "DVD";
                else
                    return "Traka";
            }

        }
    }
}


